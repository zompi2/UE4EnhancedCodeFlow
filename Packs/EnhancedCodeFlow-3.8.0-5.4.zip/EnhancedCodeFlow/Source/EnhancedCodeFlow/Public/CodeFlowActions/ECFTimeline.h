// Copyright (c) 2026 Damian Nowakowski. All rights reserved.

#pragma once

#include "ECFActionBase.h"
#include "ECFTypes.h"
#include "ECFTimeline.generated.h"

ECF_PRAGMA_DISABLE_OPTIMIZATION

UCLASS()
class ENHANCEDCODEFLOW_API UECFTimeline : public UECFActionBase
{
	GENERATED_BODY()

	friend class UECFSubsystem;

private:
	
	float GetValue()
	{
		switch (BlendFunc)
		{
			case EECFBlendFunc::ECFBlend_Linear:
				return FMath::Lerp(StartValue, StopValue, CurrentTime / Time);
			case EECFBlendFunc::ECFBlend_Cubic:
				return FMath::CubicInterp(StartValue, 0.f, StopValue, 0.f, CurrentTime / Time);
			case EECFBlendFunc::ECFBlend_EaseIn:
				return FMath::Lerp(StartValue, StopValue, FMath::Pow(CurrentTime / Time, BlendExp));
			case EECFBlendFunc::ECFBlend_EaseOut:
				return FMath::Lerp(StartValue, StopValue, FMath::Pow(CurrentTime / Time, 1.f / BlendExp));
			case EECFBlendFunc::ECFBlend_EaseInOut:
				return FMath::InterpEaseInOut(StartValue, StopValue, CurrentTime / Time, BlendExp);
		}
		return 0.f;
	}

protected:

	TUniqueFunction<void(float, float)> TickFunc;
	TUniqueFunction<void(float, float, bool)> CallbackFunc;
	TUniqueFunction<void(float, float)> CallbackFunc_NoStopped;
	float StartValue;
	float StopValue;
	float Time;
	EECFBlendFunc BlendFunc;
	float BlendExp;

	float CurrentTime;
	float CurrentValue;

	bool Setup(float InStartValue, float InStopValue, float InTime, TUniqueFunction<void(float, float)>&& InTickFunc, TUniqueFunction<void(float, float, bool)>&& InCallbackFunc, EECFBlendFunc InBlendFunc, float InBlendExp)
	{
		StartValue = InStartValue;
		StopValue = InStopValue;
		Time = InTime;

		TickFunc = MoveTemp(InTickFunc);
		CallbackFunc = MoveTemp(InCallbackFunc);

		BlendFunc = InBlendFunc;
		BlendExp = InBlendExp;

		if (TickFunc && Time > 0 && BlendExp != 0 && StartValue != StopValue)
		{
			SetMaxActionTime(Time);
			CurrentTime = 0.f;
			return true;
		}
		else
		{
#if ECF_LOGS
			UE_LOG(LogECF, Error, TEXT("ECF - [%s] Timeline failed to start. Are you sure the Ticking time is greater than 0 and Ticking Function are set properly? /n Remember, that BlendExp must be different than zero and StartValue and StopValue must not be the same!"), *Settings.Label);
#endif
			return false;
		}
	}

	bool Setup(float InStartValue, float InStopValue, float InTime, TUniqueFunction<void(float, float)>&& InTickFunc, TUniqueFunction<void(float, float)>&& InCallbackFunc, EECFBlendFunc InBlendFunc, float InBlendExp)
	{
		CallbackFunc_NoStopped = MoveTemp(InCallbackFunc);
		return Setup(InStartValue, InStopValue, InTime, MoveTemp(InTickFunc), [this](float FwdValue, float FwdTime, bool bStopped)
		{
			if (CallbackFunc_NoStopped)
			{
				CallbackFunc_NoStopped(FwdValue, FwdTime);
			}
		}, InBlendFunc, InBlendExp);
	}

	bool Reset(bool bCallUpdate) override
	{
		CurrentTime = 0.f;
		CurrentValue = GetValue();

		if (bCallUpdate)
		{
			TickFunc(CurrentValue, CurrentTime);
		}

		return true;
	}

	void Tick(float DeltaTime) override
	{
#if STATS
		DECLARE_SCOPE_CYCLE_COUNTER(TEXT("Timeline - Tick"), STAT_ECFDETAILS_TIMELINE, STATGROUP_ECFDETAILS);
#endif

#if ECF_INSIGHT_PROFILING
		TRACE_CPUPROFILER_EVENT_SCOPE("ECF - Timeline Tick");
#endif

		CurrentTime = FMath::Clamp(CurrentTime + DeltaTime, 0.f, Time);
		CurrentValue = GetValue();

		TickFunc(CurrentValue, CurrentTime);

		if (CurrentTime >= Time)
		{
			MarkAsFinished();
			Complete(false);
		}
	}

	void Complete(bool bStopped) override
	{
		if (CallbackFunc)
		{
			CallbackFunc(CurrentValue, CurrentTime, bStopped);
		}
	}

	float GetActionTime() const override
	{
		return CurrentTime;
	}

	bool SetActionTime(float NewTime, bool bCallUpdate) override
	{
		CurrentTime = FMath::Clamp(CurrentTime + NewTime, 0.f, Time);
		CurrentValue = GetValue();
		if (bCallUpdate)
		{
			TickFunc(CurrentValue, CurrentTime);
			if (CurrentTime >= Time)
			{
				MarkAsFinished();
				Complete(false);
			}
		}
		return true;
	}
};

ECF_PRAGMA_ENABLE_OPTIMIZATION