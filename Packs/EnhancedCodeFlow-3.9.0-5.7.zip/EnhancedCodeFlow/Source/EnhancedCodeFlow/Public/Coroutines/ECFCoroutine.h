// Copyright (c) 2026 Damian Nowakowski. All rights reserved.

#pragma once

#if defined(__cpp_impl_coroutine) && __has_include(<coroutine>)

#define ECF_WITH_COROUTINES 1

#include <coroutine>
#include "ECFHandle.h"
#include "ECFLogs.h"

/**
 * Defining coroutine handlers and promises in order to get coroutines work.
 */

struct FECFCoroutinePromise;
using FECFCoroutineHandle = std::coroutine_handle<FECFCoroutinePromise>;

struct FECFCoroutine : FECFCoroutineHandle
{
	using promise_type = ::FECFCoroutinePromise;
};

struct FECFCoroutinePromise
{
	FECFCoroutinePromise()
	{
#if (ECF_LOGS && ECF_LOGS_VERBOSE)
		UE_LOG(LogECF, Log, TEXT("Coroutine Created"));
#endif
	}

	~FECFCoroutinePromise()
	{
#if (ECF_LOGS && ECF_LOGS_VERBOSE)
		UE_LOG(LogECF, Log, TEXT("Coroutine Destroyed"));
#endif
	}

	FECFCoroutine get_return_object() { return { FECFCoroutine::from_promise(*this) }; }
	std::suspend_never initial_suspend() noexcept { return {}; }
	std::suspend_never final_suspend() noexcept { return {}; }
	void return_void() 
	{
#if (ECF_LOGS && ECF_LOGS_VERBOSE)
		UE_LOG(LogECF, Log, TEXT("Coroutine return_void with ActionHandle: %s"), *ActionHandle.ToString());
#endif
		bHasFinished = true;
	}
	void unhandled_exception() {}
	bool bHasFinished = false;
	bool bStopped = false;
	bool bTimedOut = false;
	FECFHandle ActionHandle;
	void AssignHandle(const FECFHandle& NewHandle)
	{
		ActionHandle = NewHandle;
		bHasFinished = false;
		bStopped = false;
		bTimedOut = false;
	}
};

#else

/**
 * Create dummy implementations of coroutine handles if coroutines are not supported by a compiler.
 */

#include "ECFHandle.h"

#define ECF_WITH_COROUTINES 0

using FECFCoroutine = void;

struct FECFCoroutinePromise
{
	bool bHasFinished = false;
	bool bStopped = false;
	bool bTimedOut = false;
	FECFHandle ActionHandle;
	void AssignHandle(const FECFHandle& NewHandle) {}
};

struct FECFCoroutineHandle 
{
	void resume() {}
	void destroy() {}

	FECFCoroutinePromise CoroPromise;
	FECFCoroutinePromise& promise() { return CoroPromise; }
};

#define co_await static_assert(false, "Trying to use co_await without coroutine support!")
#define co_return static_assert(false, "Trying to use co_return without coroutine support!")

#endif