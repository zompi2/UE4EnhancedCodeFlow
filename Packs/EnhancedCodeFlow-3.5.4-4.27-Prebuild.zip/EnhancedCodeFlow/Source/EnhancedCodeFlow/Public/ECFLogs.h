// Copyright (c) 2025 Damian Nowakowski. All rights reserved.

#pragma once

#include "CoreMinimal.h"

ENHANCEDCODEFLOW_API DECLARE_LOG_CATEGORY_EXTERN(LogECF, Log, All);
